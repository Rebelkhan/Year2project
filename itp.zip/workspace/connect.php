<!--*
 *  Connect to databse
 *
 * Date e.g. 21/3/2016
 *
 * @reference http://www.codingcage.com/2015/01/user-registration-and-login-script-using-php-mysql.html
 *
 -->
<?php
$host="localhost";
$user="andremac96";
$password="";
$db="dbtest";
$conn = mysqli_connect($host,$user,$password,$db);
?>